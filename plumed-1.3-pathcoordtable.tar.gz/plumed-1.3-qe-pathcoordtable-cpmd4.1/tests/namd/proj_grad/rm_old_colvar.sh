#!/bin/bash
rm -rf COLVAR
