#include "metadyn.h"

void PREFIX zpathcoordtable_restraint(int i_c, struct mtd_data_s *mtd_data)
{

  int i, j, ix, isol, isp1, isp2, i1, i2, j1, j2, ipair, iall, ifr;
  int nn = colvar.nn[i_c], mm = colvar.mm[i_c];
  int nat = pathctz_data.nat, nfr = pathctz_data.nfr, nsp = pathctz_data.nsp;
  rvec rij, center2;
  real num, iden, mod_rij, rdist, func, dfunc, rNdist, rMdist, r_0, d_0;
  real ncoord, tmp, tmp1, tmp2, norm, zpath;
  real threshold, lambda=pathctz_data.lambda;
  real mycoord[nat][nsp]; // coord. number of atom j wrt species k
  real dcdr[nat][nsp][colvar.natoms[i_c]][3], dist[nfr];

  threshold=pow(0.00001,1./(nn-mm));

  // calculations
  for (isol=0;isol<nat;isol++) { // *** loop on solute atoms
    i1=pathctz_data.index[isol];   // first atom: solute, index relative to host MD program
    j1=pathctz_data.indexcv[isol]; // first atom: solute, index relative to colvar.cvatoms
    isp1=pathctz_data.species[isol]; // species of first atom
    // printf("DEBUG  i1 j1 isp1 = %d %d %d\n",i1,j1,isp1);
    j2=-1; 
    for (isp2=0;isp2<nsp;isp2++) { // ** loop on species of second atom
      r_0=pathctz_data.r_0[isp1+nsp*isp2];
      d_0=pathctz_data.d_0[isp1+nsp*isp2];
      // printf("DEBUG  isp1 isp2 r_0 d_0 = %3d %3d %8.3f %8.3f\n",isp1,isp2,r_0,d_0);
      // initialize sums
      ncoord=0.;
      mycoord[isol][isp2]=0;
      for(i=0;i<colvar.natoms[i_c];i++) { for(ix=0;ix<3;ix++) { dcdr[isol][isp2][i][ix] = 0.; } }
      //
      for (iall=0;iall<pathctz_data.nspecies[isp2];iall++) { // * loop on all atoms       
        j2++;                       // second atom: all, index relative to colvar.cvatoms
        if (j1==j2) continue;
        i2=colvar.cvatoms[i_c][j2]; // second atom: all, index relative to host MD program
        // printf("DEBUG  i2 j2 isp2 = %d %d %d\n",i2,j2,isp2);
        // distance
        if(colvar.cell_pbc[i_c]){
          minimal_image(mtd_data->pos[i1], mtd_data->pos[i2], &mod_rij, rij);
        } else {
          rij[0] = mtd_data->pos[i1][0]-mtd_data->pos[i2][0];
          rij[1] = mtd_data->pos[i1][1]-mtd_data->pos[i2][1];
          rij[2] = mtd_data->pos[i1][2]-mtd_data->pos[i2][2];
          mod_rij  = sqrt(rij[0]*rij[0]+rij[1]*rij[1]+rij[2]*rij[2]);
        };
        rdist = (mod_rij-d_0)/r_0;
        // analitic limit of the switching function 
        if(rdist<=0.){
         ncoord+=1.;
         dfunc=0.;
        }else if(rdist>0.999999 && rdist<1.000001){
         ncoord+=nn/mm;
         dfunc=0.5*nn*(nn-mm)/mm;
        }else if(rdist>threshold){
         dfunc=0.;
        }else{
          rNdist = pow(rdist, nn-1);
          rMdist = pow(rdist, mm-1);
          num = 1.-rNdist*rdist;
          iden = 1./(1.-rMdist*rdist);
          func = num*iden;
          ncoord += func;
          dfunc = ((-nn*rNdist*iden)+(func*(iden*mm)*rMdist))/(mod_rij*r_0);
        }
        // gradients
        for(ix=0;ix<3;ix++) {
          dcdr[isol][isp2][j1][ix] += dfunc*rij[ix];
          dcdr[isol][isp2][j2][ix] -= dfunc*rij[ix];
        }
      } // * loop on all atoms
      mycoord[isol][isp2]=ncoord;
      // printf("DEBUG  isol isp2 mycoord = %d %d %8.3f\n",isol,isp2,ncoord);
    } // ** loop on species of second atom
  } // *** loop on solute atoms

//      colvar.myder[i_c][j1][ix] += ()*dcdr[j1][ix]
//      colvar.myder[i_c][j2][ix] += -dfunc*rij[ix];

  norm=0.;
  for (ifr=0;ifr<nfr;ifr++) { // **** loop on frames
    dist[ifr]=0.;
    for(isol=0;isol<nat;isol++){ 
      for(isp2=0;isp2<nsp;isp2++){ 
        tmp=( mycoord[isol][isp2] - pathctz_data.coord[isol][isp2][ifr] ); 
        dist[ifr]+=tmp*tmp;
//        printf("DEBUG C Cref (z CV): ifr isol isp2 = %4d %4d %4d %9.5f %9.5f\n", ifr, isol ,isp2, mycoord[isol][isp2], pathctz_data.coord[isol][isp2][ifr]);
      }
    }
    // no sqrt !!! if(dist[ifr]>0.){ dist[ifr]=sqrt(dist[ifr]); } 
    tmp=exp(-lambda*dist[ifr]);
    norm+=tmp; // norm = Z
  } // **** loop on frames

  // printf("DEBUG norm(z CV) = %9.5f\n",norm);

  // gradients
  for (i=0;i<colvar.natoms[i_c];i++) { 
    for (ix=0;ix<3;ix++) { 
      tmp2 = 0.;
      for (ifr=0;ifr<nfr;ifr++) { 
        tmp = 0.; //   d D_ifr / d R_i,ix
        for (isol=0;isol<nat;isol++) {
          for (isp2=0;isp2<nsp;isp2++) {
            tmp += 2.0 * ( mycoord[isol][isp2] - pathctz_data.coord[isol][isp2][ifr] ) * dcdr[isol][isp2][i][ix];   
          }
        }
        tmp2 += exp(-lambda*dist[ifr]) * tmp; 
      }
      colvar.myder[i_c][i][ix] = (1.0/norm)*tmp2;
    }
  }

  colvar.ss0[i_c] = -(1.0/lambda)*log(norm);

}

//--------------------------------------------------------------------------------------------------------------

int PREFIX read_zpathcoordtable(char **word, int count, t_plumed_input *input, FILE *fplog)
{
  int i, iw, iat, j, k, help;
  double r_0, d_0;
  double delta = 0.0;
  char string[400];
  // to read the file 'frames.dat'
  FILE *file;
  char w1[10],w2[10];
  int nat,nfr,nsp;

  real threshold, value,dd,tmp;
  help=0;
  d_0=0.;

  colvar.cell_pbc[count]=1; // default is PBC

  iw=seek_word(word,"NSP");
  if(iw>=0) { 
    sscanf(word[iw+1],"%i", &pathctz_data.nsp); // number of species
    nsp=pathctz_data.nsp;
    pathctz_data.nspecies = int_1d_array_alloc(nsp);
    pathctz_data.r_0 = float_1d_array_alloc(nsp*nsp);
    pathctz_data.d_0 = float_1d_array_alloc(nsp*nsp);
  } else { fprintf(fplog,"|- NEEDED NSP KEYWORD FOR ZPATHCOORDTABLE\n"); help=1;}
  iw = seek_word(word,"LIST");
  if(iw>=0 && nsp>0){   
    for(k=0;k<nsp;k++){
           j=plumed_get_group(word[iw+1+k],&colvar.cvatoms[count],colvar.natoms[count],input,fplog);
           colvar.natoms[count]+=j; // total atoms
           pathctz_data.nspecies[k]=j; // atoms of this species
    }
  } else{ fprintf(fplog,"|- NEEDED LIST KEYWORD FOR ZPATHCOORDTABLE\n"); help=1; } 
  iw=seek_word(word,"SIGMA");
  if(iw>=0){ sscanf(word[iw+1],"%lf", &delta);
             colvar.delta_r[count]  = (real) delta; }
  iw=seek_word(word,"LAMBDA");
  if(iw>=0){ sscanf(word[iw+1],"%lf", &pathctz_data.lambda); }
  else{ fprintf(fplog,"|- NEEDED LAMBDA KEYWORD FOR ZPATHCOORDTABLE\n"); help=1; }
  iw=seek_word(word,"NN");
  if(iw>=0) { 
    sscanf(word[iw+1],"%i", &colvar.nn[count]); // NN
  } else { fprintf(fplog,"|- NEEDED NN KEYWORD FOR ZPATHCOORDTABLE\n"); help=1; }
  iw=seek_word(word,"MM");
  if(iw>=0) { 
    sscanf(word[iw+1],"%i", &colvar.mm[count]); // MM
  } else { fprintf(fplog,"|- NEEDED MM KEYWORD FOR ZPATHCOORDTABLE\n"); help=1;}

  iw=seek_word(word,"R_0");
  if(iw>=0) {
    fprintf(fplog," R_0 MATRIX :\n");
    k=0;
    for(i=0;i<nsp;i++){
      for(j=0;j<nsp;j++){
        // order: for atoms A B C -> A-A, A-B, A-C, B-B, B-C, C-C
        if (j>=i) {
          sscanf(word[iw+1+k],"%lf", &r_0);
          k++;
          pathctz_data.r_0[i+nsp*j] = (real) r_0; // r_0 for each pair
          pathctz_data.r_0[j+nsp*i] = (real) r_0; // r_0 for each pair
       }
        fprintf(fplog,"  %8.3f",pathctz_data.r_0[i+nsp*j]);
      }
      fprintf(fplog,"\n");
    }
  } else { fprintf(fplog,"|- NEEDED R_0 KEYWORD FOR SPATHCOORDTABLE\n"); help=1;}

  iw=seek_word(word,"D_0");
  if(iw>=0) {
    fprintf(fplog," D_0 MATRIX :\n");
    k=0;
    for(i=0;i<nsp;i++){
      for(j=0;j<nsp;j++){
        // order: for atoms A B C -> A-A, A-B, A-C, B-B, B-C, C-C
        if (j>=i) {
          sscanf(word[iw+1+k],"%lf", &d_0);
          k++;
          pathctz_data.d_0[i+nsp*j] = (real) d_0; // d_0 for each pair
          pathctz_data.d_0[j+nsp*i] = (real) d_0; // d_0 for each pair
        }
        fprintf(fplog,"  %8.3f",pathctz_data.d_0[i+nsp*j]);
      }
      fprintf(fplog,"\n");
    }
  }

  iw=seek_word(word,"NOPBC");
  if(iw>=0) {colvar.cell_pbc[count] = 0;}
  iw=seek_word(word,"PBC");
  if(iw>=0) {colvar.cell_pbc[count] = 1;}

  if(help){
          fprintf(fplog, "\n-ZPATHCOORDTABLE CV: WRONG SYNTAX\n");
          fprintf(fplog, "e.g.:     \n");
          fprintf(fplog, "ZPATHCOORDTABLE NSP 2 LIST <g1> <g2> NN 8 MM 16 R_0 1.3 1.0 1.0 LAMBDA 3.2 SIGMA 0.1 [NOPBC]\n");
          plumed_error("PluMed dead with errors: check log file");
  }

  fprintf(fplog, "%1i-ZPATHCOORDTABLE CV\n", count+1);

  // read file "frames.dat"
  // TODO: add lots of checks
  help=0;
  file = fopen("frames.dat","r");
  if(file==NULL) {
    fprintf(fplog, "ERROR: MISSING FILE 'frames.dat'\n");
    help=1;
  }else{
    fscanf(file,"%s %d %s %d",w1,&pathctz_data.nat,w2,&pathctz_data.nfr);
    fprintf(fplog, "READING FILE frames.dat:  natoms nframes = %d %d\n",pathctz_data.nat,pathctz_data.nfr);
    pathctz_data.index   = int_1d_array_alloc(pathctz_data.nat);
    pathctz_data.indexcv = int_1d_array_alloc(pathctz_data.nat);
    pathctz_data.species = int_1d_array_alloc(pathctz_data.nat);
    pathctz_data.coord   = float_3d_array_alloc(pathctz_data.nat,nsp,pathctz_data.nfr);
    for (i=0;i<pathctz_data.nfr;i++) {
      fprintf(fplog, "   FRAME %d : (iatom ispecies coords...)\n",i+1);
      fscanf(file,"%d",&j);
      for (j=0;j<pathctz_data.nat;j++) {
        fscanf(file,"%d %d",&pathctz_data.index[j],&pathctz_data.species[j]);
        fprintf(fplog, "            %d %d   ",pathctz_data.index[j],pathctz_data.species[j]); 
        pathctz_data.index[j]--; pathctz_data.species[j]--; // inside plumed atoms and species start from 0
        for (k=0;k<nsp;k++) {
          fscanf(file,"%lf",&pathctz_data.coord[j][k][i]); // coord. number of atom j wrt species k in frame i
          fprintf(fplog, " %8.3f",pathctz_data.coord[j][k][i]);  
        }
        fprintf(fplog, "\n");
      }
    }
  }
  fclose(file);
  // check that all solute atoms belong to the groups given with LIST:
  for (j=0;j<pathctz_data.nat;j++) {
    k=0;
    for (i=0;i<colvar.natoms[count];i++) {
      if (pathctz_data.index[j]==colvar.cvatoms[count][i]) {
        pathctz_data.indexcv[j]=i; // index of solute atom j wrt to array colvar.cvatoms
        k=1;
      } 
    }
    if (k==0) {
      fprintf(fplog, "ERROR: SOLUTE ATOM %d IS NOT IN THE GROUPS GIVEN WITH 'LIST'\n",pathctz_data.index[j]+1);
      help=1;
    }
    // printf("DEBUG  j pathctz_data.index pathctz_data.indexcv = %d %d %d\n",j,pathctz_data.index[j],pathctz_data.indexcv[j]);    
  }

  // computing D (ideal) between pairs of frames, to check if lambda is reasonable:
  fprintf(fplog, "|- (IDEAL) DISTANCE BETWEEN FRAMES :\n"); 
  for (i=0;i<pathctz_data.nfr-1;i++) {
    dd=0.; 
    for (j=0;j<pathctz_data.nat;j++) {
      for (k=0;k<nsp;k++) {
        tmp=(pathctz_data.coord[j][k][i]-pathctz_data.coord[j][k][i+1]);
        dd+=tmp*tmp;
      }
    }
    fprintf(fplog, "FR %d FR %d   D = %9.2f   LAMBDA*D = %9.4f\n",i+1,i+2,dd,pathctz_data.lambda*dd); 
  }

//         fprintf(fplog, " NAT 3 FRAMES 3     \n");
//         fprintf(fplog, "  1           \n");
//         fprintf(fplog, "   12  1  0 1    \n");
//         fprintf(fplog, "   25  2  1 1    \n");
//         fprintf(fplog, "   27  2  1 1    \n");
//         fprintf(fplog, "  2              \n");
//         fprintf(fplog, "   12  1  0 0    \n");
//         fprintf(fplog, "   25  2  1 1    \n");
//         fprintf(fplog, "   27  2  1 0    \n");
//         fprintf(fplog, "  3              \n");
//         fprintf(fplog, "   12  1  1 0    \n");
//         fprintf(fplog, "   25  2  0 1    \n");
//         fprintf(fplog, "   27  2  1 0    \n");

  colvar.type_s[count]   = 78;

//  fprintf(fplog, "%1i-COORDINATION NUMBER OF (1st SET: %i ATOMS) WRT (2nd SET: %i ATOMS); ", count+1, pathctz_data.nspecies[0], pathctz_data.nspecies[1]);
//  if(colvar.cell_pbc[count]) fprintf(fplog, " PBC ON");
//  else                       fprintf(fplog, " PBC OFF");
//  if (logical.do_hills) fprintf(fplog," SIGMA %f\n",colvar.delta_r[count]);
//  else fprintf(fplog,"\n"); 
//  fprintf(fplog, "|--FUNCTIONAL FORM: (1-((d_ij-d_0)/r_0)^n) / (1-((d_ij-d_0)/r_0)^m) \n");
//  fprintf(fplog, "|--PARAMETERS: n= %i m= %i r_0= %f d_0= %f\n", colvar.nn[count], colvar.mm[count], colvar.r_0[count], colvar.d_0[count]);
//
//  threshold=pow(0.00001,1./(colvar.nn[count]-colvar.mm[count]));
//  value=(1.-pow(threshold,colvar.nn[count]))/(1.-pow(threshold,colvar.mm[count]));
//  fprintf(fplog, "|--CUTOFF VALUE: %f\n",value);
//  fprintf(fplog, "|--CUTOFF DISTANCE: %f\n",threshold*r_0+d_0);

  snew(colvar.myder[count], colvar.natoms[count]);

  iat=0;
  for (k=0;k<nsp;k++){ 
    fprintf(fplog,"|- ATOMS OF SPECIES %d: \n",k+1);
    for(i=0;i<pathctz_data.nspecies[k];i++){
      fprintf(fplog," %d ",colvar.cvatoms[count][iat++]+1);if((i+1)%20==0)fprintf(fplog,"\n");
    }
    fprintf(fplog,"\n");
  }
  fprintf(fplog,"\n");

  return colvar.natoms[count]; 
}
