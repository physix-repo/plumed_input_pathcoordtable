
awk '{
 if (NR==1) { rows=$2; cols=$4; frames=$6 }
 if (NR==2) { for (i=1;i<=rows;i++){ rlab[i]=$(i+1) } }
 if (NR==3) { for (i=1;i<=cols;i++){ clab[i]=$(i+1) } }
 if (NR>3)  { 
   if ($1=="FRAME") { 
     irow=0 
   }else{
     irow++
     for (jcol=1;jcol<=cols;jcol++) { t[irow,jcol]=$jcol }
     if (irow==rows) { 
       printf "REMARK ARG="
       for (j=1;j<=cols;j++){ for (i=1;i<=rows;i++){ 
         if(i*j>1) { printf "," }
         printf "%s%s.lessthan",rlab[i],clab[j]
       }}
       for (j=1;j<=cols;j++){ for (i=1;i<=rows;i++){
         printf " %s%s.lessthan=%4.2f",rlab[i],clab[j],t[i,j]
       }}
       printf "\nEND\n"
     }
   }
 }
}' tables.txt > path.pdb

